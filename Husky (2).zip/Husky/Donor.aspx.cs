﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Organ : System.Web.UI.Page
{
   SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();
    
    protected void Page_Load(object sender, EventArgs e)
    {
        con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
        con.Open();
    }
    
    protected void Button1_Click2(object sender, EventArgs e)
    {
      SqlCommand cmd = new SqlCommand("insert into donor " + "(Donar_id,Donar_name,Donar_contactnumber,Hospital_registered,Donar_address,Blood_Group) values(@Donar_id,@Donar_name,@Donar_contactnumber,@Hospital_registered,@Donar_address,@Blood_Group)", con);
        cmd.Parameters.AddWithValue("@Donar_id", Did.Text);
        cmd.Parameters.AddWithValue("@Donar_name", Dname.Text);
        cmd.Parameters.AddWithValue("@Donar_contactnumber", Dcn.Text);
        cmd.Parameters.AddWithValue("@Hospital_registered",Hr.Text);
        cmd.Parameters.AddWithValue("@Donar_address", Da.Text);
        cmd.Parameters.AddWithValue("@Blood_Group",Bg.Text);
        cmd.ExecuteNonQuery();
        orlbl.Text = "value added";
    }
}
