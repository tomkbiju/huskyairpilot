﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Pilot : System.Web.UI.Page
{
    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();

    protected void Page_Load(object sender, EventArgs e)
    {
        con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
        con.Open();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into Pilot " + "(Pilot_id,Pilot_name,current_address,contactnumber,flight_id) values(@Pilot_id,@Pilot_name,@current_address,@contactnumber,@flight_id)", con);
        cmd.Parameters.AddWithValue("@Pilot_id", pid.Text);
        cmd.Parameters.AddWithValue("@Pilot_name", pn.Text);
        cmd.Parameters.AddWithValue("@current_address", ca.Text);
        cmd.Parameters.AddWithValue("@contactnumber", cn.Text);
        cmd.Parameters.AddWithValue("@flight_id", fid.Text);

        cmd.ExecuteNonQuery();
        plbl.Text = "value inserted";
    }
    protected void lgp_Click(object sender, EventArgs e)
    {
        Session["user2"] = null;
        Response.Redirect("Pilot_Login.aspx");
    }
}
