﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;



public partial class Register : System.Web.UI.Page
{
    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
        con.Open();
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string input = passtxt.Text;


        MD5 md5 = System.Security.Cryptography.MD5.Create();


        byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);


        byte[] hash = md5.ComputeHash(inputBytes);
        // step 2, convert byte array to hex string


        StringBuilder sb = new StringBuilder();


        for (int i = 0; i < hash.Length; i++)


        {


            sb.Append(hash[i].ToString("x2"));


        }
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HuskyConnectionString"].ConnectionString);

        con.Open();

        string query1 = "select count(*) from Login where Email='" + passtxt.Text + "'";

        SqlCommand com1 = new SqlCommand(query1, con);


        int temp = Convert.ToInt32(com1.ExecuteScalar().ToString());

        if (temp == 1)

        {

            Response.Write("User already Registered");

        }

        else

        {

            string query = "Insert into Login" + "(Email,Password)values(@Email,@Password)";

            SqlCommand com = new SqlCommand(query, con);


            com.Parameters.AddWithValue("@Email", usertxt.Text);


            com.Parameters.AddWithValue("@Password", sb.ToString());

            com.ExecuteNonQuery();

            Response.Write("Data stored successfully");

            con.Close();

        }

    }
}