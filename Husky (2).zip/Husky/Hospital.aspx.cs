﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Hospital : System.Web.UI.Page
{
    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();

    protected void Page_Load(object sender, EventArgs e)
    {
        con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
        con.Open();
    }
    protected void hsubmit_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into Hospital " + "(Hospital_id,place,hospital_name,hospital_address) values(@Hospital_id,@place,@hospital_name,@hospital_address)", con);
        cmd.Parameters.AddWithValue("Hospital_id", hid.Text);
        cmd.Parameters.AddWithValue("@place", hp.Text);
        cmd.Parameters.AddWithValue("@hospital_name", hn.Text);
        cmd.Parameters.AddWithValue("@hospital_address", ha.Text);
    
        cmd.ExecuteNonQuery();
        hlbl.Text = "value inserted";
    }
}

       