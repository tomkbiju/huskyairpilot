﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Doctor : System.Web.UI.Page
{
    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
        con.Open();
    }
    
    protected void insert_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into Doctor " + "(Phy_Id,Name,Speciality,Hospital_Id,Gender,Salary,Email) values(@Phy_Id,@Name,@Speciality,@Hospital_Id,@Gender,@Salary,@Email)", con);
        cmd.Parameters.AddWithValue("@Phy_Id", Pid.Text);
        cmd.Parameters.AddWithValue("@Name", nme.Text);
        cmd.Parameters.AddWithValue("@Speciality", speci.Text);
        cmd.Parameters.AddWithValue("@Hospital_Id", hid.Text);
        cmd.Parameters.AddWithValue("@Gender", gend.Text);
        cmd.Parameters.AddWithValue("@Salary", sal.Text);
        cmd.Parameters.AddWithValue("@Email", email.Text);
        cmd.ExecuteNonQuery();
        dlbl.Text = "value inserted";
    }
    protected void log_Click(object sender, EventArgs e)
    {
        Session["user3"] = null;
        Response.Redirect("Doctor_Login.aspx");
    }
}
