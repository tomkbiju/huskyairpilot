﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class pilot_login : System.Web.UI.Page
{
    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();
    SqlDataAdapter sda = new SqlDataAdapter();
    DataSet ds = new DataSet();
    
    protected void Page_Load(object sender, EventArgs e)
    {
     if (Session["Email"] != null)
        {
            Response.Redirect("Pilot.aspx");
        }
        else

            con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
        con.Open();

    }

    protected void plbt_Click(object sender, EventArgs e)
    {
       String user2 = pln.Text.Trim();
        
        cmd.CommandText = "select * from Pilot_login where Email='" + pln.Text + "' and Password='" + plp.Text + "'";
        cmd.Connection = con;
        sda.SelectCommand = cmd;
        sda.Fill(ds, "Patient_login");
        if (ds.Tables[0].Rows.Count > 0)
        {
                Session["user2"] = user2;
                Response.Redirect("Pilot.aspx");
            }
            else 
        {
            pplg.Text = "Password not match";
        }

    }
    protected void TextBox3_TextChanged(object sender, EventArgs e)
    {
       SqlCommand cmd = new SqlCommand("insert into Pilot_login " + "(Name,Email,Password,Confirm_Password) values(@Name,@Email,@Password,@Confirm_Password)", con);
       cmd.Parameters.AddWithValue("@Name", prn.Text);
       cmd.Parameters.AddWithValue("@Email", pre.Text);
       cmd.Parameters.AddWithValue("@Password", prp.Text);
       cmd.Parameters.AddWithValue("@confirm_Password",prcp.Text);
        cmd.ExecuteNonQuery();
        prlb.Text = "Welcome You are registered";
    }
    protected void prbt_Click(object sender, EventArgs e)
    {

    }
    protected void phm_Click(object sender, EventArgs e)
    {
        Session["user2"] = null;
        Response.Redirect("homepage.aspx");
    }
}