﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Passenger : System.Web.UI.Page
{
    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();

    protected void Page_Load(object sender, EventArgs e)
    {
        con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
        con.Open();

    }
    

    protected void ppbtn_Click(object sender, EventArgs e)
    {
    SqlCommand cmd = new SqlCommand("insert into Passenger " + "(Name,Contact,Address,Gender,Age) values(@Name,@Contact,@Address,@Gender,@Age)", con);
        cmd.Parameters.AddWithValue("@Name", ppname.Text);
        cmd.Parameters.AddWithValue("@Contact", ppcontact.Text);
        cmd.Parameters.AddWithValue("@Address", ppaddress.Text);
        cmd.Parameters.AddWithValue("@Age", ppage.Text);
        cmd.Parameters.AddWithValue("@Gender", ppgen.Text);
        cmd.ExecuteNonQuery();
        pplb.Text = "value inserted";
    
    }
    protected void hph_Click(object sender, EventArgs e)
    {
        Session["user3"] = null;
        Response.Redirect("homepage.aspx");
    }
}
