﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Request : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // T1.Text = Request.QueryString["Name"].ToString();
    }
    protected void Insert_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True");
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into Booking(Patient_Id,Patient_Name,disease,Orgin,Destination,Date,No_Passengers,Weight) values(" + T1.Text + ",'" + nme.Text + "','" + TextBox1.Text + "','" + speci.Text + "','" + hid.Text + "','" + gend.Text + "','" + sal.Text + "','" + wht.Text + "')", con);
        cmd.ExecuteNonQuery();


        con.Close();
        Response.Write("<script>alert('Requested!!!')</script>");
        String Email = Text1.Text;
        String from = hid.Text;
        String to = speci.Text;
        String date = gend.Text;
        MailMessage mail = new MailMessage("tomkbiju007@gmail.com", Text1.Text);


        mail.Subject = "Booking confirmation.... ";
        mail.Body = "Your appointment is confirmed From:\n " + from + "\n to" + to + " \n on " + date +
            " \n Please carry this Email";
        mail.IsBodyHtml = false;

        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.gmail.com";
        smtp.EnableSsl = true;
        smtp.UseDefaultCredentials = false;
        NetworkCredential networkcred = new NetworkCredential("tomkbiju007@gmail.com", "Vavachi468@");
        smtp.Credentials = networkcred;
        smtp.Port = 587;
        smtp.Send(mail);
        

        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "success", "alert('Ticket booked');window.location ='request.aspx';", true);
        drlbl.Text = "Requested";
    }

}

