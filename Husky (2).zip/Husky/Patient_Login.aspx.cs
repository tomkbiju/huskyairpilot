﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Patient_Login : System.Web.UI.Page
{

    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();
    SqlDataAdapter sda = new SqlDataAdapter();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] != null)
        {
            Response.Redirect("Patient.aspx");
        }
        else

            con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
        con.Open();
    }

    protected void plogbtn_Click(object sender, EventArgs e)
    {
        String user1 = dln.Text.Trim();
        
        cmd.CommandText = "select * from Patient_login where Email='" + dln.Text + "' and Password='" + dlp.Text + "'";
        cmd.Connection = con;
        sda.SelectCommand = cmd;
        sda.Fill(ds, "Patient_login");
        if (ds.Tables[0].Rows.Count > 0)
        {
                Session["user1"] = user1;
                Response.Redirect("Patient.aspx");
            }
        else
        {
            pllbl.Text = "Password not match";
        }
        }

    protected void Sign_up_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into Patient_login " + "(Name,Email,Password,Confirm_Password) values(@Name,@Email,@Password,@Confirm_Password)", con);
        cmd.Parameters.AddWithValue("@Name", dnl.Text);
        cmd.Parameters.AddWithValue("@Email", del.Text);
        cmd.Parameters.AddWithValue("@Password", dpl.Text);
        cmd.Parameters.AddWithValue("@Confirm_Password", dcpl.Text);
        cmd.ExecuteNonQuery();
        pslb.Text = "Welcome You are registered";
    }
    protected void hp_Click(object sender, EventArgs e)
    {
        Session["user1"] = null;
        Response.Redirect("homepage.aspx");
    }
}