﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Get_Doctor : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow gr1 = GridView1.SelectedRow;
        gdn.Text = gr1.Cells[1].Text;
        gdln.Text = gr1.Cells[2].Text;
        gda.Text = gr1.Cells[3].Text;
        gdv.Text = gr1.Cells[4].Text;
        gdc.Text = gr1.Cells[5].Text;


    }
}