﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Drawing;
using System.Net;
using System.Net.Mail;


public partial class forgotpassword : System.Web.UI.Page
{
    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();

    protected void Page_Load(object sender, EventArgs e)
    {


        con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
        con.Open();
    }

    protected void pwd_Click1(object sender, EventArgs e)
    {
        string mainconn = ConfigurationManager.ConnectionStrings["HuskyConnectionString"].ConnectionString;
        SqlConnection sqlconn = new SqlConnection(mainconn);
        string sqlquery = "select Email_Id,Password from [dbo].[Admin1_Login] where Email_Id=@Email_Id";
        SqlCommand sqlcomm = new SqlCommand(sqlquery);
        sqlcomm.Parameters.AddWithValue("@Email_Id", TextBox1.Text);
        sqlconn.Open();
        sqlcomm.Connection = con;
        SqlDataReader sdr = sqlcomm.ExecuteReader();

        if (sdr.Read())
        {
            string Email_Id = sdr["Email_Id"].ToString();
            string Password = sdr["Password"].ToString();
            MailMessage mm = new MailMessage("tomkbiju007@gmail.com", TextBox1.Text);

            mm.Subject = "your password!";
            mm.Body = String.Format("Hello:<h1>{0}</h1>is your user id<br/>your password is<h1>{1}</h1>", Email_Id, Password);
            mm.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;
            NetworkCredential nc = new NetworkCredential();
            nc.UserName = "tomkbiju007@gmail.com";
            nc.Password = "Vavachi468@";

            smtp.UseDefaultCredentials = true;
            smtp.Credentials = nc;
            smtp.Port = 587;
            smtp.Send(mm);
            Label1.Text = "your password has been sent to" + TextBox1.Text;
            Label1.ForeColor = Color.Green;
        }
        else
        {
            Label1.Text = TextBox1.Text + "This email id is not registered!";
            Label1.ForeColor = Color.Red;
        }

    }
}

