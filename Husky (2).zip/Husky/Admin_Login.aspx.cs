﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.ServiceModel.Channels;
using System.Net.Mail;

public partial class Admin_Login : System.Web.UI.Page
{
    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();
    SqlDataAdapter sda = new SqlDataAdapter();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        

            con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
        con.Open();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        {
            String user3 = TextBox1.Text.Trim();

            cmd.CommandText = "select * from Admin1_Login where Email_Id='" + TextBox1.Text + "' and Password='" + TextBox2.Text + "'";
            cmd.Connection = con;
            sda.SelectCommand = cmd;
            sda.Fill(ds, "Admin1_Login");
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session["user3"] = user3;
                Response.Redirect("Admin.aspx");
            }
            else
            {
                Session["user3"] = user3;
                Response.Redirect("Admin.aspx");
            }

        }
    }
    protected void dbtl_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into Admin1_login " + "(Name,Email_Id,Password,Confirm_Password) values(@Name,@Email_Id,@Password,@Confirm_Password)", con);
        cmd.Parameters.AddWithValue("@Name", dnl.Text);
        cmd.Parameters.AddWithValue("@Email_Id", del.Text);
        cmd.Parameters.AddWithValue("@Password", dpl.Text);
        cmd.Parameters.AddWithValue("@confirm_Password", dcpl.Text);
        cmd.ExecuteNonQuery();
        drlbl.Text = "Welcome You are registered";
    }
    protected void dh_Click(object sender, EventArgs e)
    {
        Session["user3"] = null;
        Response.Redirect("homepage.aspx");
    }


    protected void LinkButton2_Click(object sender, EventArgs e)
    {

    }
}