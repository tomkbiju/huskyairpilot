﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using System.Data;
using System.Security.Cryptography;
using System.Text;
using System.Web.Compilation;
using System.Data.SqlClient;

public partial class Doctor_login : System.Web.UI.Page
{

    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();
    SqlDataAdapter sda = new SqlDataAdapter();
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Email"] != null)
        {
            Response.Redirect("Doctor.aspx");
        }
        else

            con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
            con.Open();
    }
    protected void dlbt_Click(object sender, EventArgs e)
    {
        String user3 = dln.Text.Trim();

        cmd.CommandText = "select * from Doctor_login where Email='" + dln.Text + "' and Password='" + dlp.Text + "'";
        cmd.Connection = con;
        sda.SelectCommand = cmd;
        sda.Fill(ds, "Doctor_login");
        if (ds.Tables[0].Rows.Count > 0)
        {
            Session["user3"] = user3;
            Response.Redirect("Doctor.aspx");
        }
        else
        {
            dllb.Text = "Password not match";
        }

    }
    protected void dbtl_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into Doctor_login " + "(Name,Email,Password,Confirm_Password) values(@Name,@Email,@Password,@Confirm_Password)", con);
        cmd.Parameters.AddWithValue("@Name", dnl.Text);
        cmd.Parameters.AddWithValue("@Email", del.Text);
        cmd.Parameters.AddWithValue("@Password", dpl.Text);
        cmd.Parameters.AddWithValue("@Confirm_Password", dcpl.Text);
        cmd.ExecuteNonQuery();
        drlbl.Text = "Welcome You are registered";
    }
    protected void dh_Click(object sender, EventArgs e)
    {
        Session["user3"] = null;
        Response.Redirect("homepage.aspx");
    }
}