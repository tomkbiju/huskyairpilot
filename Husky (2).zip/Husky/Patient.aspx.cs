﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data;
using System.Data.SqlClient;

public partial class Patient : System.Web.UI.Page
{
    SqlCommand cmd = new SqlCommand();
    SqlConnection con = new SqlConnection();
    SqlDataAdapter sda = new SqlDataAdapter();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {
        

            con.ConnectionString = "Data Source=WIN-46N27566SE6;Initial Catalog=Husky;Integrated Security=True";
        con.Open();
    }
    
    protected void psubmit_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into Patient " + "(Pati_Id,Name,Address,Gender,Phone) values(@Pati_Id,@Name,@Address,@Gender,@Phone)", con);
        cmd.Parameters.AddWithValue("@Pati_Id", Pant.Text);
        cmd.Parameters.AddWithValue("@Name", Nme.Text);
        cmd.Parameters.AddWithValue("@Address", Addres.Text);
        cmd.Parameters.AddWithValue("@Gender", Gend.Text);
        cmd.Parameters.AddWithValue("@Phone", Phn.Text);
        cmd.ExecuteNonQuery();
        ptlb.Text = "value inserted";
      
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["user1"] = null;
        Response.Redirect("Patient_Login.aspx");
    }

    protected void Submit_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("insert into Patient " + "(Pati_Id,Name,Address,Gender,Phone) values(@Pati_Id,@Name,@Address,@Gender,@Phone)", con);
        cmd.Parameters.AddWithValue("@Pati_Id", Pant.Text);
        cmd.Parameters.AddWithValue("@Name", Nme.Text);
        cmd.Parameters.AddWithValue("@Address", Addres.Text);
        cmd.Parameters.AddWithValue("@Gender", Gend.Text);
        cmd.Parameters.AddWithValue("@Phone", Phn.Text);
        cmd.ExecuteNonQuery();
        ptlb.Text = "value added";
    }
}
