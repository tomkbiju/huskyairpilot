﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Get_Hospital : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox4_TextChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow gr1 = GridView1.SelectedRow;
        ghn.Text = gr1.Cells[1].Text;
        ghl.Text = gr1.Cells[2].Text;
        ghd.Text = gr1.Cells[3].Text;
        gho.Text = gr1.Cells[4].Text;
        ghs.Text = gr1.Cells[5].Text;
        ghc.Text = gr1.Cells[6].Text;
        
    }
}