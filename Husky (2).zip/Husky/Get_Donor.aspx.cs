﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Get_Organ : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow gr1 = GridView1.SelectedRow;
        gon.Text = gr1.Cells[1].Text;
        god.Text = gr1.Cells[2].Text;
        goda.Text = gr1.Cells[3].Text;
        gob.Text = gr1.Cells[4].Text;
       
   
    }
}