﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Get_Passenger : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow gr1 = GridView1.SelectedRow;
        gpna.Text = gr1.Cells[1].Text;
        gpad.Text = gr1.Cells[2].Text;
        gpco.Text = gr1.Cells[3].Text;
        gpgn.Text = gr1.Cells[4].Text;
        gpag.Text = gr1.Cells[5].Text;
        
    }
}